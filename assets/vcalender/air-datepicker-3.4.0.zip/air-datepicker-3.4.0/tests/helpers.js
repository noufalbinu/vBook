export const DAY =  1000 * 60 * 60 * 24;
