module.exports = require('../../shared/componentPrompt');
