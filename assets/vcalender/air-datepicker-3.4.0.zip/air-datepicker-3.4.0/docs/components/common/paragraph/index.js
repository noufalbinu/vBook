import Paragraph from './paragraph';
export default Paragraph;

